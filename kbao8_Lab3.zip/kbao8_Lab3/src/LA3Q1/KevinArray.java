package LA3Q1;

public class KevinArray {

    //array to help define all the methods
    private Pair[] testArray;

    //constructor without parameter
    public KevinArray() {
        testArray = new Pair[0];
    }

    //method to return length of array
    public int getSize(){
        return testArray.length;
    }

    //takes away the final element of the array and creates updated array
    public Pair removeFromLastIndex(){
        if (testArray.length == 0){
            return null;
        }
        Pair removed = testArray[testArray.length - 1];

        Pair[] newArray = new Pair[testArray.length - 1];
        System.arraycopy(testArray, 0, newArray, 0, testArray.length - 1);
        testArray = newArray;

        return removed;
    }

    //takes away the first element of the array and creates updated array
    public Pair removeFromFirstIndex(){
        if (testArray.length == 0){
            return null;
        }
        Pair removed = testArray[0];

        Pair[] newArray = new Pair[testArray.length - 1];
        System.arraycopy(testArray, 1, newArray, 0, testArray.length - 1);
        testArray = newArray;

        return removed;
    }

    //returns array in string form
    public String toString(){
        String result = "[";
        for (int i = 0; i < testArray.length; i++) {
            result += testArray[i].toString();
            if (i != testArray.length - 1){
                result += ",";
            }
        }
        result += "]";
        return result;
    }

    //adds on a new element to the end of the array
    public void addAtLastIndex(Pair elementAdded){
        Pair[] newArray = new Pair[testArray.length + 1];

        for (int i = 0; i < testArray.length; i++) {
            newArray[i] = testArray[i];
        }
        newArray[testArray.length] = elementAdded;
        testArray = newArray;
    }

}
