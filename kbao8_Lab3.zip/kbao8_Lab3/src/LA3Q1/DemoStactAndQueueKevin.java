package LA3Q1;
import java.util.InputMismatchException;
import java.util.Scanner;

public class DemoStactAndQueueKevin {

    //used to obtain info from the user
    public static Scanner input = new Scanner(System.in);

    //header method containing necessary info
    public static void myHeader(int labNum){
        System.out.println("=======================================================");
        System.out.printf("Lab Exercise %d-Q1", labNum); //Lab # + Question #
        System.out.println("Prepared by: Kevin Bao"); //Name
        System.out.println("Student Number: 251410147"); //Student Number
        System.out.println("Brief Description: Learning how to work with Stack and Queue operations"); //Description
        System.out.println("=======================================================");
    }

    //footer to place at the end of the program
    public static void myFooter(int labNum){
        System.out.println("=======================================================");
        System.out.printf("Completion of Lab Exercise %d is successful! \n", labNum);
        System.out.println("Signing off - Kevin Bao");
        System.out.println("=======================================================");
    }

    //method containing all operations related to Stack
    public static void stackDemo(KevinArray arr) {
        System.out.print("You have an empty stack: " + arr);

        //loop to make sure it can infinitely repeat
        while (true) {

            //menu for user's reference
            System.out.println("\nStack Operation Menu:");
            System.out.println("a: Push");
            System.out.println("b: Pop");
            System.out.println("c: Exit");
            System.out.print("Enter your choice: ");

            //gets the user's choice
            String choice = input.nextLine().trim().toLowerCase();

            //switch case for each possible input/scenario
            switch (choice) {

                //pushing in an element
                case "a":
                    System.out.print("Let's push a data item into the stack... ");
                    try {
                        System.out.print("Enter Year: ");
                        int year = input.nextInt();
                        input.nextLine();
                        System.out.print("Enter Name: ");
                        String name = input.nextLine();

                        arr.addAtLastIndex(new Pair(year, name));
                        System.out.println("The current stack: " + arr);

                    //making sure the input is valid
                    } catch (InputMismatchException e) {
                        System.out.println("Invalid input! Try again.");
                        input.nextLine();
                    }
                    break;

                //removing an element
                case "b":
                    System.out.print("Let's pop a data item... ");
                    Pair poppedElement = arr.removeFromLastIndex();
                    if (poppedElement == null) {
                        System.out.println("FYI: The stack is empty!");
                    } else {
                        System.out.println(poppedElement + " is removed! The current stack: " + arr);
                    }
                    break;

                //exit the stack menu
                case "c":
                    System.out.println("Ending Stack-demo! Goodbye!");
                    return;

                default:
                    System.out.println("Invalid choice!");

            } //end switch
        } //end while loop
    } //end stack method

    //method for all queue operations
    public static void queueDemo(KevinArray arr) {
        System.out.println("You have an empty queue: " + arr);

        while (true) {
            System.out.println("\nQueue Operation Menu:");
            System.out.println("a: Enqueue");
            System.out.println("b: Dequeue");
            System.out.println("c: Exit");
            System.out.print("Enter your choice: ");

            //obtain user's choice
            String userChoice = input.nextLine().trim().toLowerCase();

            //same format as stack
            switch (userChoice) {
                case "a":
                    System.out.println("Let's enqueue a data-item in the queue....");
                    try {
                        System.out.print("Enter year: ");
                        int year = input.nextInt();
                        input.nextLine(); // clear buffer
                        System.out.print("Enter name: ");
                        String name = input.nextLine();

                        arr.addAtLastIndex(new Pair<>(year, name));
                        System.out.println("The current queue: " + arr);
                    } catch (InputMismatchException ex) {
                        System.out.println("Invalid input! Try again.");
                        input.nextLine();
                    }
                    break;

                case "b":
                    System.out.println("Let's dequeue a data-item ....");
                    Pair dequeued = arr.removeFromFirstIndex();
                    if (dequeued == null)
                        System.out.println("FYI: The queue is empty!");
                    else
                        System.out.println(dequeued + " is dequeued! The current queue: " + arr);
                    break;

                case "c":
                    System.out.println("Ending Queue-demo! Goodbye!");
                    return;

                default:
                    System.out.println("Invalid choice!");
            }
        }
    }

    //driver method
    public static void main(String[] args) {

        //call header
        myHeader(3);

        //used for testing only
        /*
        Pair<Integer, String> testPair = new Pair<>(3, "John");
        System.out.println("Test Pair output: " + testPair);
         */

        //declare new array to use in all operations
        KevinArray x;

        //loop to make it run infinitely
        while (true) {
            System.out.println("Main Demo-Menu:");
            System.out.println(" 1: Stack");
            System.out.println(" 2: Queue");
            System.out.println(" 3: Exit");
            System.out.print(" Enter your choice: ");

            String mainChoice = input.nextLine().trim();

            //switch case to run through stack, queue, or exit if the user wishes to
            switch (mainChoice) {

                //if user picks 1, go straight to the stack menu
                case "1":
                    x = new KevinArray();  // instantiate when user picks Stack
                    stackDemo(x);
                    break;

                //if user picks 2, go straight to queue menu
                case "2":
                    x = new KevinArray();  // instantiate when user picks Queue
                    queueDemo(x);
                    break;

                //if user picks 3, exit the program entirely, but print the footer before doing that
                case "3":
                    System.out.println("Goodbye!");
                    myFooter(3);
                    return;

                default:
                    System.out.println("Invalid choice!");

            }

        }
    }
}

