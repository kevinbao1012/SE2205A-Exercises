package Q1L1;

import java.util.Scanner;

public class TestingExecutionTime {

    public static Scanner input = new Scanner(System.in); //creating Scanner type variable to collect data from the user

    //header method containing the Lab Exercise number and question, Name, Student Number, and brief description
    public static void myHeader(int exerciseNum){
        System.out.println("=======================================================");
            System.out.printf("Lab Exercise %d-Q%d", exerciseNum, exerciseNum); //Lab # + Question #
            System.out.println("Prepared by: Kevin Bao"); //Name
            System.out.println("Student Number: 251410147"); //Student Number
            System.out.println("Brief Description: Using methods to check the time needed to execute the code"); //Description
        System.out.println("=======================================================");
    }

    //footer to place at the end of the program
    public static void myFooter(int exerciseNum){
        System.out.println("=======================================================");
        System.out.printf("Completion of Lab Exercise %d is successful! \n", exerciseNum);
        System.out.println("Signing off - Kevin Bao");
        System.out.println("=======================================================");
    }

    //An iterative method for the factorial, using a while loop and a bottom-up approach
    public static double interativeMethodForFactorial(int factorial){
        double factorialValue = 1;  int i = 1; //setting the factorial value at one initially, and the counter for the while loop
            while (i <= factorial){
            factorialValue = factorialValue*i;
            i++;
            }
        return factorialValue;
    }

    //recursive method for calculating factorial, using a top-down approach
    public static double recursiveMethodFactorial(int factorial){
        if(factorial==0){ //since this method normally returns NaN if 0 is entered, this if statement manually changes it to read as 0! = 1
            return 1;
        }
        else {
            return factorial*recursiveMethodFactorial(factorial-1); //recursive method for any value given other than 0
        }
    }

    //driver method
    public static void main(String[] args) {

        //call header, for exercise 1
        myHeader(1);

        //obtaining a value from the user to calculate the factorial of
        System.out.println("Please enter an integer number that you would like to calculate the factorial for: ");
        int n = input.nextInt();

        //validation to make sure the number is not negative
        while (n < 0){
            System.out.println("Please make sure the number is 0 or greater: ");
            n = input.nextInt();
        }

        //trying the iterative method and keeping track of the time required
        long startTimeInterative = System.nanoTime();
        double resultInterative = interativeMethodForFactorial(n);
        long endTimeInterative = System.nanoTime();

        //calculating time based on start and end time
        long timeElapsedInterative = endTimeInterative - startTimeInterative;

        //trying the recursive method and keeping track of the time required
        long startTimeRecursive = System.nanoTime();
        double resultRecursive = recursiveMethodFactorial(n);
        long endTimeRecursive = System.nanoTime();

        //calculating time based on start and end time
        long timeElapsedRecursive = endTimeRecursive - startTimeRecursive;

        //printing out the results for both methods
        //iterative
        System.out.printf("The factorial of %d is %.2e%n", n, resultInterative);
        System.out.printf("Time taken by iterative solution inside main: %d ms\n", timeElapsedInterative);
        //recursive
        System.out.printf("The factorial of %d is %.2e%n", n, resultRecursive);
        System.out.printf("Time taken by recursive solution: %d ms\n", timeElapsedRecursive);

        //calling the footer method, for exercise 1
        myFooter(1);
    }

}
