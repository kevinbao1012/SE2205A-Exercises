package Q3L3;
import java.util.Scanner;

public class WorkingWithArrays {

    public static Scanner input = new Scanner(System.in); //create scanner variable to obtain necessary inputs from the user

    //method to calculate/filter all necessary information
    public static double[] mma5MethodKevin(double[] numbers){
        //define necessary variables
        int divisibleNumberCount = 0; //counter which will increase everytime a number divisible by 5 is found
        double sum = 0;  //variable to store the sum of all said divisible numbers
        double maxValue = numbers[0]; //variable to store the maximum value within the entire array
        double minValue = numbers[0]; //variable to store the minimum value within the entire array

        //Enhanced for loop to run through all the numbers and filter out the divisible, and max and min numbers
        for (double num : numbers) {
            //checking for if divisible by 5
            if (num % 5 == 0){
                divisibleNumberCount++;
                sum += num;
            }

            //max and min values
            maxValue = Math.max(maxValue, num);
            minValue = Math.min(minValue, num);
        }

        //Statement to display how many divisible numbers were present
        System.out.printf("Kevin found %d divisible numbers \n",divisibleNumberCount);
        double averageValue;

        //finding the average of all divisible numbers
        if (divisibleNumberCount == 0){ //manual case to make sure there are sufficient number of divisible numbers, and if not, making it 0
            averageValue = 0.0;
        } else { //calculating average the regular way
            averageValue = sum/divisibleNumberCount;
        }

        //variable to hold student number
        double YourStudentNumber = 251410147;

        //returning all required information
    return new double[]{maxValue, minValue, averageValue, YourStudentNumber};
    } //end of method

    //header method
    public static void myHeader(int exerciseNumber){
        System.out.println("=======================================================");
        System.out.printf("Lab Exercise 1-Q%d", exerciseNumber);
        System.out.println("Prepared by: Kevin Bao");
        System.out.println("Student Number: 251410147");
        System.out.println("Brief Description: Using methods to check the time needed to execute the code");
        System.out.println("=======================================================");
    }

    //footer method
    public static void myFooter(int exerciseNum){
        System.out.println("=======================================================");
        System.out.printf("Completion of Lab Exercise %d is successful! \n", exerciseNum);
        System.out.println("Signing off - Kevin Bao");
        System.out.println("=======================================================");
    }

    //driver method
    public static void main(String[] args) {

        //calling the header
        myHeader(3);

        //obtaining the users desired array size
        System.out.println("Please enter the desired array size: ");
        int arraySize = input.nextInt();
        double[] numbers = new double[arraySize];

        //filling in the array with a for loop and values given by the user
        for (int i = 0; i < arraySize; i++) {
            System.out.println("Enter Value: ");
            numbers[i] = input.nextDouble();
        }

        //displaying all the information
        System.out.println("The desired results are as follows: ");

        //calling the method to get it all
        double[] finalArray = mma5MethodKevin(numbers);

        //finalArray layout [maxValue, minValue, averageValue, studentNumber].
        System.out.println("Max Value: " + finalArray[0]);
        System.out.println("Min Value: " + finalArray[1]);
        System.out.println("Average Value of the numbers divisible by 5: " + finalArray[2]);
        System.out.printf("Student Number: %.0f\n", finalArray[3]);

        //calling the footer method
        myFooter(3);
    } //end driver method
}
