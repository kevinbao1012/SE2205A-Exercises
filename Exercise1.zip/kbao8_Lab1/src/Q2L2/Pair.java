package Q2L2;

//Class to be used later
public class Pair<K>{
    private K first;
    private K second;

    //constructor class with no parameters
    public Pair(){
        first = null;
        second = null;
    }//end constructor

    public void setPair(K first, K second){
        this.first = first;
        this.second = second;
    } //end setPair

    public void reversePair(){
        K temp = first;
        first = second;
        second = temp;
    } //end reversePair

    public String toString(){
        return first.toString() + ", " + second.toString();
    } //end toString

}


