package Q2L2;

public class GenericClassDemo {

    //method to print information inside of arrays
    public static <T>void print(T[] t){
        for (T result: t){
            System.out.print(result + " ");
        }
        System.out.println(); //making sure this is the only information on the line, then moving cursor to a new line
        }

    public static void main(String[] args) {

        //manually creating header
        System.out.println("=======================================================");
            System.out.println("Lab Exercise 1-Q2");
            System.out.println("Prepared by: Kevin Bao");
            System.out.println("Student Number: 251410147");
            System.out.println("Brief Description: Learning how to work with generic classes in Java");
        System.out.println("=======================================================");
        //end header

        //declaring the numbers for the ordered pair
        double first = 2.5;
        double second = 1.0;

        //use constructor class to create Double type Pair variable
        Pair<Double> doublePair = new Pair<>() {};

        //use setPair to bring the values listed above into the Pair variable
        doublePair.setPair(first, second);

        //Display the regular order, and reverse order
        //regular order
        System.out.println("Regular Order: " + doublePair);
        //reverse order
        doublePair.reversePair();
        System.out.println("Reversed Order: " + doublePair);

        //assigning arrays with the necessary information for below
        String[] nameArray = {"Kevin", "Bao"}; //name
        Integer[] currentDateArray = {18,9,2025}; //date of writing the code

        //footer, using the arrays above and the print() method
        System.out.println("=======================================================");
        print(nameArray);
        print(currentDateArray);
        System.out.println("=======================================================");
    }
}
