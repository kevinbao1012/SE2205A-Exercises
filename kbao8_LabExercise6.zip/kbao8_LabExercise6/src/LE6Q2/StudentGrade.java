package LE6Q2;

public class StudentGrade implements Comparable<StudentGrade>{

    //private data fields
    private int grade;
    private String firstName;
    private String lastName;

    //constructor with fields
    public StudentGrade(int grade, String firstName, String lastName) {
        this.grade = grade;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    //getter methods
    public String getterFirstName() {
        return firstName;
    }
    public String getterLastName() {
        return lastName;
    }
    public int getterGrade() {
        return grade;
    }

    // setter methods
    public void setterFirstName(String firstName) { this.firstName = firstName; }
    public void setterLastName(String lastName) { this.lastName = lastName; }
    public void setterGrade(int grade) {
        this.grade = grade;
    }

    //overrided compare to method
    @Override
    public int compareTo(StudentGrade other) {
        return Integer.compare(this.grade, other.grade);
    }

    //overrided method to turn into string
    @Override
    public String toString() {
        return String.format("%-12s %-12s : %4d", firstName, lastName, grade);
    }
}
