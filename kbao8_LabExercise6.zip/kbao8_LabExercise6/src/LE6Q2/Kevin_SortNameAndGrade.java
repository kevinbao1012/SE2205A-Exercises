package LE6Q2;

import java.util.Collections;
import java.util.Vector;

public class Kevin_SortNameAndGrade {

    //header method
    public static void myHeader(int labNum) {
        System.out.println("=======================================================");
        System.out.printf("Lab Exercise %d-Q2 \n", labNum); //Lab # + Question #
        System.out.println("Prepared by: Kevin Bao"); //Name
        System.out.println("Student Number: 251410147"); //Student Number
        System.out.println("Brief Description: Learning to work with vector classes"); //Description
        System.out.println("=======================================================");
    }

    //footer to place at the end of the program
    public static void myFooter(int labNum) {
        System.out.println("=======================================================");
        System.out.printf("Completion of Lab Exercise %d is successful! \n", labNum);
        System.out.println("Signing off - Kevin Bao");
        System.out.println("=======================================================");
    }

    public static void main(String[] args) {
        myHeader(6);

        //first and last name collections
        String[] fnArray = {"Hermione", "Ron", "Harry", "Luna", "Ginny",
                "Draco", "Dean", "Fred"};
        String[] lnArray = {"Granger", "Weasley", "Potter", "Lovegood",
                "Weasley", "Malfoy", "Thomas", "Weasley"};

        //random grades between 60 and 85
        Integer[] grd = {
                (int) (60 + Math.random() * 26),
                (int) (60 + Math.random() * 26),
                (int) (60 + Math.random() * 26),
                (int) (60 + Math.random() * 26),
                (int) (60 + Math.random() * 26),
                (int) (60 + Math.random() * 26),
                (int) (60 + Math.random() * 26),
                (int) (60 + Math.random() * 26)};

        //create vector and fill it
        Vector<StudentGrade> sg = new Vector<>();
        for (int i = 0; i < fnArray.length; i++) {
            sg.add(new StudentGrade(grd[i], fnArray[i], lnArray[i]));
        }


        System.out.println("The unsorted array: ");
        for (StudentGrade s : sg) {
            System.out.println("  " + s);
        }
        System.out.println();
        Collections.sort(sg);

        //sort by grades
        System.out.println("The sorted array based on grades: ");
        for (StudentGrade s : sg) {
            System.out.println("  " + s);
        }
        System.out.println();

        StudentGrade[] sgCopy = new StudentGrade[fnArray.length];
        sg.copyInto(sgCopy);

        //sort based off first name and print out
        sort(sgCopy, 1);
        System.out.println("The sorted array based on first name: ");
        printArray(sgCopy);
        System.out.println();

        //sort based off last name and print out
        sort(sgCopy, 2);
        System.out.println("The sorted array based on last name: ");
        printArray(sgCopy);
    }

    //method to print out the sorted arrays
    public static void printArray(StudentGrade[] arr) {
        for (StudentGrade s : arr)
            System.out.println("  " + s);
    }

    //method to sort the arrays
    public static void sort(StudentGrade[] arr, int key) {

        //run through the entire length of the array
        for (int i = 1; i < arr.length; i++) {

            StudentGrade temp = arr[i];
            int j = i - 1;

            while (j >= 0) {

                boolean greater = false;

                if (key == 1) {
                    // Sort by FIRST NAME
                    greater = arr[j].getterFirstName().compareTo(temp.getterFirstName()) > 0;

                } else if (key == 2) {
                    // Sort by LAST NAME
                    greater = arr[j].getterLastName().compareTo(temp.getterLastName()) > 0;
                }

                if (!greater)
                    break;

                arr[j + 1] = arr[j];
                j--;
            }

            arr[j + 1] = temp;
        }
    }
}
