package LE6Q1;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class KevinTestingSortingMethods {

    //selection sort method
    public static <T extends Comparable<? super T>>long selectionSort(T[] a) {
        long start = System.nanoTime();

        int n = a.length;
        for (int i = 0; i < n - 1; i++) {
            int min = i;

            //finding index of the smallest element in the section still unsorted
            for (int j = i + 1; j < n; j++) {
                if (a[j].compareTo(a[min]) < 0)
                    min = j;
            }

            //swap smallest element into current index
            T temp = a[i];
            a[i] = a[min];
            a[min] = temp;
        }

        return System.nanoTime() - start; //return time elapsed in ns
    }

    //bubble sort method
    public static <T extends Comparable<? super T>>long bubbleSort(T[] a) {
        long start = System.nanoTime();

        //boolean value to track whether need to swap or not
        boolean swapped;

        for (int i = 0; i < a.length - 1; i++) {
            swapped = false;
            for (int j = 0; j < a.length - i - 1; j++) {
                //swap if smaller
                if (a[j].compareTo(a[j + 1]) > 0) {
                    T temp = a[j];
                    a[j] = a[j + 1];
                    a[j + 1] = temp;
                    swapped = true;
                }
            }

            //allows for early exit if no swaps
            if (!swapped) break; // optimization
        }


        return System.nanoTime() - start;
    }

    //insertion sort method
    public static <T extends Comparable<? super T>>long insertionSort(T[] a) {
        long start = System.nanoTime();

        for (int i = 1; i < a.length; i++) {

            T key = a[i];
            int index = i - 1;

            //shift larger elements to the right
            while (index >= 0 && a[index].compareTo(key) > 0) {
                a[index + 1] = a[index];
                index--;
            }

            //put the key into the sorted position
            a[index + 1] = key;
        }

        return System.nanoTime() - start;
    }

    //merge sort method
    public static <T extends Comparable<? super T>>long mergeSort(T[] S) {
        long start = System.nanoTime();    // begin timing

        int n = S.length;

        //size 1 already sorted by default, so only run if size 2
        if (n >= 2) {

            int mid = n / 2;

            //split array into 2 parts
            T[] S1 = Arrays.copyOfRange(S, 0, mid);
            T[] S2 = Arrays.copyOfRange(S, mid, n);

            // Recursive calls (return values ignored)
            mergeSort(S1);
            mergeSort(S2);

            // Merge the two halves back together
            int i = 0, j = 0;
            while (i + j < n) {
                if (j == S2.length || (i < S1.length && S1[i].compareTo(S2[j]) <= 0))
                    S[i + j] = S1[i++];
                else
                    S[i + j] = S2[j++];
            }
        }

        long end = System.nanoTime();      // end timing
        return end - start;
    }

    //quick sort method
    public static <T extends Comparable<? super T>> long quickSort(T[] s, int a, int b){
        long start = System.nanoTime();   // start timing at top-level call

        if (a < b) {

            //set the pivot to last element
            T pivot = s[b];
            int left = a;
            int right = b - 1;

            //partition step
            while (left <= right) {
                while (left <= right && s[left].compareTo(pivot) < 0)
                    left++;
                while (left <= right && s[right].compareTo(pivot) > 0)
                    right--;
                if (left <= right) {
                    T tmp = s[left];
                    s[left] = s[right];
                    s[right] = tmp;
                    left++;
                    right--;
                }
            }

            // Put pivot into final correct position
            T tmp = s[left];
            s[left] = s[b];
            s[b] = tmp;

            // Recursive calls — returned long values ignored
            quickSort(s, a, left - 1);
            quickSort(s, left + 1, b);
        }

        long end = System.nanoTime();     // end timing
        return end - start;
    }

    public static long bucketSort(Integer[] a, int first, int last, int maxDigits){
        long start = System.nanoTime();

        int n = last - first + 1;
        int[][] bucket = new int[10][n];
        int[] count = new int[10];
        int factor = 1;

        //digit by digit
        for (int d = 0; d < maxDigits; d++) {

            //reset the counter
            for (int i = 0; i < 10; i++)
                count[i] = 0;


            for (int i = first; i <= last; i++) {
                int digit = (a[i] / factor) % 10;
                bucket[digit][count[digit]++] = a[i];
            }

            //build the sorted array again
            int index = first;
            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < count[i]; j++) {
                    a[index++] = bucket[i][j];
                }
            }

            factor *= 10;
        }

        return System.nanoTime() - start;
    }

    //header method
    public static void myHeader(int labNum){
        System.out.println("=======================================================");
        System.out.printf("Lab Exercise %d-Q1 \n", labNum); //Lab # + Question #
        System.out.println("Prepared by: Kevin Bao"); //Name
        System.out.println("Student Number: 251410147"); //Student Number
        System.out.println("Brief Description: Learning how to implement and use various sorting methods"); //Description
        System.out.println("=======================================================");
    }

    //footer to place at the end of the program
    public static void myFooter(int labNum){
        System.out.println("=======================================================");
        System.out.printf("Completion of Lab Exercise %d is successful! \n", labNum);
        System.out.println("Signing off - Kevin Bao");
        System.out.println("=======================================================");
    }

    public static void main(String[] args) {

        myHeader(6);

        //array to hold the numbers to be sorted
        int sz = 5;

        //array used to be sorted each time, and a backup so the unsorted numbers can be referenced each time
        Integer[] arr = new Integer[sz];
        Integer[] backupArr = new Integer[sz];

        //fill the array with random numbers between 13 and 93
        for (int i = 0; i < sz; i++){
            arr[i] = 13 + (int) (Math.random() * (93 - 13 + 1));
        }

        //create the backup
        System.arraycopy(arr, 0, backupArr, 0, sz);

        //convert to list
        List<Integer> unsortedList = Arrays.asList(arr);

        //Collections sort
        System.out.println("The unsorted list: " + unsortedList.toString());
        long startTime = System.nanoTime();
        Collections.sort(unsortedList);
        long endTime = System.nanoTime();
        System.out.println("Time elapsed for collection sort: " + (endTime - startTime) + " ns");
        List<Integer> sortedList = Arrays.asList(arr);
        System.out.println("Sorted list using collection sort: " + sortedList.toString());
        System.out.println();
        System.arraycopy(backupArr, 0, arr, 0, sz);

        //selection sort
        System.out.println("The unsorted list: " + Arrays.asList(backupArr));
        long time = selectionSort(arr);
        System.out.println("Time Elapsed for Selection Sort: " + time + " ns");
        System.out.println("Sorted list using selection sort: " + Arrays.asList(arr));
        System.out.println();
        System.arraycopy(backupArr, 0, arr, 0, sz);


        //bubble sort
        System.out.println("The unsorted list: " + Arrays.asList(backupArr));
        time = bubbleSort(arr);
        System.out.println("Time Elapsed for Bubble Sort: " + time + " ns");
        System.out.println("Sorted list using Selection Sort: " + Arrays.asList(arr));
        System.out.println();
        System.arraycopy(backupArr, 0, arr, 0, sz);

        //insertion sort
        System.out.println("The unsorted list: " + unsortedList);
        time = insertionSort(arr);
        System.out.println("Time Elapsed for Insertion Sort: " + time + " ns");
        System.out.println("Sorted list using Insertion Sort: " + Arrays.asList(arr));
        System.out.println();
        System.arraycopy(backupArr, 0, arr, 0, sz);

        //merge sort
        System.out.println("The unsorted list: " + unsortedList);
        time = mergeSort(arr);
        System.out.println("Time Elapsed for Merge Sort: " + time + " ns");
        System.out.println("Sorted list using Merge Sort: " + Arrays.asList(arr));
        System.out.println();
        System.arraycopy(backupArr, 0, arr, 0, sz);

        //quick sort
        System.out.println("The unsorted list: " + unsortedList);
        time = quickSort(arr, 0, sz - 1);
        System.out.println("Time Elapsed for Quick Sort: " + time + " ns");
        System.out.println("Sorted list using Quick Sort: " + Arrays.asList(arr));
        System.out.println();
        System.arraycopy(backupArr, 0, arr, 0, sz);

        //bucket sort
        System.out.println("The unsorted list: " + unsortedList);
        time = bucketSort(arr, 0, sz - 1, 2);   // if values 13–93 → 2 digits
        System.out.println("Time Elapsed for Bucket Sort: " + time + " ns");
        System.out.println("Sorted list using Bucket Sort: " + Arrays.asList(arr));
        System.out.println();
        System.arraycopy(backupArr, 0, arr, 0, sz);

        //footer
        myFooter(6);
    }
}
