package L4Q1;

public class MyStudent {

    //private data fields
    private String firstName;
    private double score;

    //constructor without parameter containing my own information
    public MyStudent(){
        this.firstName = "Kevin";
        this.score = 85.50;
    }

    //constructor with parameters
    public MyStudent(String firstName, double score){
        this.firstName = firstName;
        this.score = score;
    }

    //Overriding toString method
    @Override
    public String toString(){
        //format: Name: score
        return String.format("%s: %.2f", firstName, score);
    }

}
