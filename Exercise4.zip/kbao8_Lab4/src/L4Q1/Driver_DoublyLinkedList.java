package L4Q1;

public class Driver_DoublyLinkedList {

    //header method
    public static void myHeader(int labE_number, int q_number){
        System.out.println("=======================================================");
        System.out.printf("Lab Exercise %d-Q%d\n", labE_number, q_number);
        System.out.println("Student Number: 251410147");
        System.out.println("Goal of this Exercise: Practicing working with doubly linked lists and adding in entries into predisignated locations");
        System.out.println("=======================================================");
    }

    //footer method
    public static void myFooter(int labE_number, int q_number){
        System.out.println("=======================================================");
        System.out.printf("Completion of Lab Exercise %d-Q%d is successful!\n", labE_number, q_number);
        System.out.println("Signing off - Kevin Bao");
        System.out.println("=======================================================");
    }

    //driver
    public static void main(String[] args) {

        //call header
        myHeader(4, 1);

        //create the doubly linked list to store all the information
        System.out.println("Adding 4 students to the list.");
        DoublyLinkedList<MyStudent> kevinList = new DoublyLinkedList<>();

        //create the entries
        MyStudent s0 = new MyStudent();
        MyStudent s1 = new MyStudent("Harry", 67.35);
        MyStudent s2 = new MyStudent("Luna", 87.50);
        MyStudent s3 = new MyStudent("Vincent", 60.50);
        MyStudent s4 = new MyStudent("Hermoine", 89.20);

        //add in 4 of the entries using addLast() method
        kevinList.addLast(s0);
        kevinList.addLast(s1);
        kevinList.addLast(s2);
        kevinList.addLast(s3);

        //show the user the current state of the list
        System.out.println("The list Content: ");
        System.out.println(kevinList);

        //use findNodes to pinpoint the location where we want the final entry
        System.out.println("Adding Hermoine to the list in between Harry and Vincent.....");
        DoublyLinkedList.Node<MyStudent> nodeS2 = kevinList.findNode(s2);
        DoublyLinkedList.Node<MyStudent> nodeS3 = kevinList.findNode(s3);

        //add in the final entry
        kevinList.addBetween(s4,nodeS2,nodeS3);

        //show user the final list
        System.out.println("The list Content: ");
        System.out.println(kevinList);

        //call footer
        myFooter(4, 1);
    }
}
