package L4Q2;

import java.util.Comparator;

//class that implements Comparator<T> interface for last names
public class HelperClassCompareFirstNames implements Comparator<Student> {

    //implementing the compare() method
    public int compare(Student s1, Student s2) {
        return s1.getFirstName().compareTo(s2.getFirstName());
    }
}
