package L4Q2;

import java.util.Comparator;

//class that implements Comparator<T> interface for last names
public class HelperClassCompareLastNames implements Comparator<Student> {

    //implement the compare() method
    public int compare(Student s1, Student s2) {
        return s1.getLastName().compareTo(s2.getLastName());
    }
}
