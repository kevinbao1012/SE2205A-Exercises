package L4Q2;

import java.util.ArrayList;
import java.util.Collections;

public class DriverForStudentClass {

    //header method
    public static void myHeader(Student myInfo, int labE_number, int q_number){
        System.out.println("=======================================================");
        System.out.println("Full name: " + myInfo.getFirstName() + " " + myInfo.getLastName());
        System.out.printf("Lab Exercise %d-Q%d\n", labE_number, q_number);
        System.out.println("Student Number: 251410147");
        System.out.println("Goal of this Exercise: Learn how to work with the Comaparator<T> interface");
        System.out.println("=======================================================");
    }

    //footer method
    public static void myFooter(int labE_number, int q_number){
        System.out.println("=======================================================");
        System.out.printf("Completion of Lab Exercise %d-Q%d is successful!\n", labE_number, q_number);
        System.out.println("Signing off - Kevin Bao");
        System.out.println("=======================================================");
    }

    //driver method
    public static void main(String[] args) {

        //create new Student type reference variable to display information in the header
        Student myInfo = new Student();

        //call header
        myHeader(myInfo, 4, 2);

        //create new arraylist to store all the information
        ArrayList<Student> studentList = new ArrayList<Student>();

        //add in all the students
        studentList.add(new Student());
        studentList.add(new Student("Harry", "Potter", 75.5));
        studentList.add(new Student("Ronald", "Weasley", 86.0));
        studentList.add(new Student("Hermione", "Granger", 91.7));
        studentList.add(new Student("Parvati", "Patil", 93.75));

        //
        System.out.println("=======================================================");
        System.out.println("The Score Card:");
        for (Student s : studentList) {
            System.out.println(s);
        }

        // Sort by score descending (natural order reversed)
        Collections.sort(studentList, Collections.reverseOrder());
        System.out.println("The sorted list in terms of score in descending order....");
        for (Student s : studentList) {
            System.out.println(s);
        }

        // Sort by last name ascending
        Collections.sort(studentList, new HelperClassCompareLastNames());
        System.out.println("The sorted list in terms of Last Names....");
        for (Student s : studentList) {
            System.out.println(s);
        }

        // Sort by first name ascending
        Collections.sort(studentList, new HelperClassCompareFirstNames());
        System.out.println("The sorted list in terms of First Names....");
        for (Student s : studentList) {
            System.out.println(s);
        }

        myFooter(4, 2);

    }
}
