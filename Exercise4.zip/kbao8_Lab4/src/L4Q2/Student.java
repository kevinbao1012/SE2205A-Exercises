package L4Q2;

public class Student implements Comparable<Student>{
    private Double score;
    private String firstName;
    private String lastName;

    public Student() {
        this.firstName = "Kevin";   // your own first name
        this.lastName = "Bao";      // your own last name (or any)
        this.score = 89.50;         // any default score
    }

    // Constructor with parameters
    public Student(String firstName, String lastName, Double score) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.score = score;
    }

    //getter & setter method for score
    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }

    //getter and setter method for first name
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    //getter and setter method for last name
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    //overriding the toString() method
    @Override
    public String toString() {
        // Example output: Kevin Bao: 95.75
        return String.format("%s %s: %.2f", firstName, lastName, score);
    }

    //making a customized compareTo method
    @Override
    public int compareTo(Student otherStudent) {
        return this.score.compareTo(otherStudent.score);
    }
}
