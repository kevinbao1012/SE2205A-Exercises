package Q_LE2;

public class Pair<Y,N> {

    //private data fields
    private Y key;
    private N value;

    //constructor
    public Pair(Y key, N value) {
        this.key = key;
        this.value = value;
    }

    //method to set value of "key"
    public void setKey(Y key) {
        this.key = key;
    }

    //method to set value of second value in the pair
    public void setValue(N value) {
        this.value = value;
    }

    //methods to extract the requested info from the pair
    public Y getKey() {
        return key;
    }
    public N getValue() {
        return value;
    }
}
