package Q_LE2;

//importing all necessary libraries, including Scanner, ArrayList, and Arrays
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

//driver class
    public class GenericsAndArrays_Kevin {

        //method for header
        public static void myHeader(int labNum){
            System.out.println("=======================================================");
            System.out.printf("Lab Exercise %d-Q1", labNum); //Lab # + Question #
            System.out.println("Prepared by: Kevin Bao"); //Name
            System.out.println("Student Number: 251410147"); //Student Number
            System.out.println("Brief Description: Learning how to use ArrayLists and Pair classes to print out information"); //Description
            System.out.println("=======================================================");
        }

        //footer to place at the end of the program
        public static void myFooter(int labNum){
            System.out.println("=======================================================");
            System.out.printf("Completion of Lab Exercise %d is successful! \n", labNum);
            System.out.println("Signing off - Kevin Bao");
            System.out.println("=======================================================");
        }

        //variable to collect data from the user
        public static Scanner input = new Scanner(System.in);

        //main method
        public static void main(String[] args) {

            //creating the reference Pair Array

            //setting the individual years
            ArrayList<Integer> integerArrayList = new ArrayList(Arrays.asList(2,3,4,3,2,2));
            //Adding in the names to match those years
            ArrayList<String> stringArrayList = new ArrayList(Arrays.asList("Harry","Lavender","Ron", "Hermione","Luna","Vincent"));
            //making a new Pair array to hold the combined info
            Pair<Integer, String>[] keyAndValue = new Pair[stringArrayList.size()];

            //adding in the info
            for (int i = 0; i < stringArrayList.size(); i++) {
                keyAndValue[i] = new Pair(integerArrayList.get(i), stringArrayList.get(i));
            }

            //calling header to start the program
            myHeader(2);

            //setting while true loop to make sure user can use this program as many times as they desire
            while (true) {

                //placeholder variable
                int yearValue = 0;

                //while loop to validate user has entered either 2,3 or 4
                while (true) {
                    System.out.print("Enter Academic Year (2,3 or 4): ");
                    try {
                        yearValue = input.nextInt();
                        if (yearValue == 2 || yearValue == 3 || yearValue == 4) { //making sure the integer value is correct
                            break;
                        } else {
                            System.out.println("Incorrect input! Enter Academic Year (2,3 or 4): ");
                        }
                    } catch (Exception ex) { //exception is any data type that is not an integer
                        System.out.println("Incorrect input! Enter Academic Year (2,3 or 4): ");
                        input.nextLine();
                    }
                }

                input.nextLine(); //clearing out the Scanner to collect the String type variable later

                //Collecting all relevant information from the big array and storing it in a new one called collectedNames
                ArrayList<String> collectedNames = new ArrayList<>();
                for (Pair<Integer, String> p : keyAndValue) {
                    if (p.getKey().equals(yearValue)) {
                        collectedNames.add(p.getValue());
                    }
                }

                //Printing out the requested information
                System.out.println("Found " + collectedNames.size() + " leader(s) from year " + yearValue);
                System.out.println("Here is the list:");
                System.out.println(collectedNames);

                //Asking if user wants to continue
                System.out.println("Do you wish to continue? (Press y to continue or any other key to terminate)" );
                String answer = input.nextLine();

                //if answer is y, then display footer and break the while (true) loop to end. If not, it repeats
                if (!answer.equals("y")) {
                    myFooter(2);
                    break;

                }
            }
    }
}
